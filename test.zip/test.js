
//  List/Array of elements containing integer and string

const array = [0 + "ab", 6 + "cd", 0 + "ef", 6 + "gh", 4 + "ij", 0 + "lt", 1 + "pr", 2 + "pw",]

//  Implicit type casting will be applied here and elements will be converted into string

//  Getting the elements of first half
let firstHalfArray= array.slice(0, array.length/2)


let orderedObjectArray = []

//  Getting the integer value of the elements and making an array of objects including integer (x), string and originalValue (value) 

array.map((i) => {
   let data = {
        x: i.match(/(\d+)/)[0],
        string: i.replace(/\d+/g, ''),
        value:   i.match(/(\d+)/).input
    }
   orderedObjectArray.push(data)
})

//    ELements are ordered according to the integer value

orderedObjectArray.sort((a, b) => a.x - b.x)


let orderedArray = []

// Making an array of ordered value

orderedObjectArray.map((i)=>{
    orderedArray.push(i.value)
 }
)

    let filteredSecondhalf = [] // This is the final array


//  Filtering and replacing first half element into "-"

orderedArray.map((i) => {
    if (firstHalfArray.includes(i)
    ) {
        filteredSecondhalf.push("-")
        
    } else {
        filteredSecondhalf.push(i)
    }
})

console.log(filteredSecondhalf)







